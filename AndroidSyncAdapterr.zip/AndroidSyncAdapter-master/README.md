# AndroidSyncAdapter

Collect sensor data(accelerometer, gyrometer, magnetometer) from the Android mobile device and store it in the local sqlite database.

Sync this data periodically to the cloud MySQL database using SyncAdapter, ContentProvider and a stub authenticator.
